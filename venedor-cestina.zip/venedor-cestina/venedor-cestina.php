<?php
/*
Plugin Name: Venedor čeština
Plugin URI: http://expres-web.cz
Description: Přeloží premiovou šablonu venedor do češtiny.
Author: Expres-Web
Version: 1.1
Author URI: http://expres-web.cz
*/

// Zjištění verze
require 'plugin-updates/plugin-update-checker.php';
$ExampleUpdateChecker = PucFactory::buildUpdateChecker(
	'https://raw.githubusercontent.com/expres-web/venedor-cestina/master/wp_metadata.json',
	__FILE__
);

// Soubor s funkcemi pro českou lokalizaci WordPressu (cs_CZ)...


// Nastavení správné cesty k překladům šablony...
function ew_venedor_cestina( $mofile, $domain='' ) {
  $custom_mofile = '';
  if ( in_array( $domain, array( 'venedor' ) ) ) {
    $pathinfo = pathinfo( $mofile );
    $custom_mofile = WP_PLUGIN_DIR . '/venedor-cestina/themes/' . $domain . '/' . $pathinfo['basename'];
  }
  if ( file_exists( $custom_mofile ) )
    return ( $custom_mofile );
  else
    return $mofile;
}
add_filter( 'load_textdomain_mofile', 'ew_venedor_cestina', 10, 2 );

?>